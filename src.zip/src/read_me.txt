run via: 

docker build -t foo . && docker run -it foo
